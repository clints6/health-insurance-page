// Year in footer
document.getElementById('year').textContent = new Date().getFullYear();

// Multi-step form controls
const steps = Array.from(document.querySelectorAll('.form-step'));
const nextButtons = document.querySelectorAll('.next');
const prevButtons = document.querySelectorAll('.prev');
let current = 0;
function showStep(i) { steps.forEach((s, idx) => s.classList.toggle('active', idx === i)); current = i; }
nextButtons.forEach(btn => btn.addEventListener('click', () => { if (current < steps.length - 1) showStep(current + 1); }));
prevButtons.forEach(btn => btn.addEventListener('click', () => { if (current > 0) showStep(current - 1); }));

// FAQ accordion
document.querySelectorAll('.faq-toggle').forEach(btn => {
  btn.addEventListener('click', () => {
    const content = btn.nextElementSibling;
    const isOpen = content.style.display === 'block';
    content.style.display = isOpen ? 'none' : 'block';
  });
});
